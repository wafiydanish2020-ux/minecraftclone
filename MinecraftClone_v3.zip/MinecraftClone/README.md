# MinecraftClone — Android (OpenGL ES 3.0)
**By AzrulPlayz**

Pure C++17 + OpenGL ES 3.0, no engine, NativeActivity.

---

## Struktur Project

```
MinecraftClone/
├── app/src/main/
│   ├── cpp/
│   │   ├── main.cpp              ← entry point, game loop, EGL
│   │   ├── CMakeLists.txt
│   │   ├── renderer/
│   │   │   ├── shaders.h         ← GLSL source strings
│   │   │   ├── shader_utils.h    ← compile/link helpers
│   │   │   └── texture_loader.h  ← stb_image + AAssetManager
│   │   ├── world/
│   │   │   ├── block.h           ← BlockType enum, UV atlas, face brightness
│   │   │   ├── chunk.h           ← 16³ chunk, mesh builder, VAO/VBO
│   │   │   └── world.h           ← chunk map, terrain gen, render dispatch
│   │   ├── player/
│   │   │   ├── player.h          ← movement, gravity, AABB collision
│   │   │   └── touch_input.h     ← virtual joystick + look drag
│   │   └── utils/
│   │       └── glm.h             ← minimal vec2/vec3/mat4 (no dependency)
│   └── AndroidManifest.xml
├── app/build.gradle
├── build.gradle
└── settings.gradle
```

---

## Dependencies yang perlu kamu tambahkan sendiri

| File | Sumber |
|------|--------|
| `app/src/main/cpp/utils/stb_image.h` | https://github.com/nothings/stb |
| `app/src/main/assets/textures/terrain.png` | Texture atlas 256×256 (16×16 grid), format PNG |

> **Texture atlas**: Buat sendiri atau pakai atlas dari Minecraft Java Edition resource pack (terrain.png lama, pre-1.5). Tiap tile 16×16 px.

---

## Setup di Android Studio

1. Buka **Android Studio → Open** → pilih folder `MinecraftClone/`
2. Pastikan **NDK** dan **CMake** sudah terinstall:
   - `SDK Manager → SDK Tools → NDK (Side by side)` ✓
   - `SDK Manager → SDK Tools → CMake` ✓
3. Copy `stb_image.h` ke `app/src/main/cpp/utils/`
4. Copy `terrain.png` ke `app/src/main/assets/textures/`
5. **Build → Make Project** (Ctrl+F9)
6. Run di device/emulator dengan OpenGL ES 3.0

---

## Kontrol (touch)

| Zona | Aksi |
|------|------|
| Kiri layar | Virtual joystick (gerak) |
| Kanan layar | Drag untuk lihat (look) |
| Sudut kanan atas | Tombol Jump |

---

## Fitur saat ini (v0.1)

- ✅ Terrain generation dengan fractal noise (grass, dirt, stone, pohon)
- ✅ Chunk rendering dengan face culling
- ✅ Directional face brightness
- ✅ Player movement + gravity + AABB collision
- ✅ Virtual joystick + touch look
- ✅ Sky gradient
- ✅ Texture atlas support

## Roadmap (belum diimplementasi)

- [ ] Block placing / breaking
- [ ] Inventory UI
- [ ] Chunk saving/loading
- [ ] TPP camera
- [ ] Water rendering
- [ ] Biomes
