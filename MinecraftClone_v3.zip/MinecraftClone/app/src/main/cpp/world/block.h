#pragma once
#include <cstdint>

// Texture atlas layout: 16x16 tiles, each tile = 1/16 of UV space
static constexpr float ATLAS_INV = 1.0f / 16.0f;

enum class BlockType : uint8_t {
    AIR   = 0,
    GRASS = 1,
    DIRT  = 2,
    STONE = 3,
    WOOD  = 4,
    LEAVES= 5,
    SAND  = 6,
    WATER = 7,
};

enum class Face { TOP, BOTTOM, FRONT, BACK, LEFT, RIGHT };

// Returns (u0, v0) – bottom-left of tile in atlas
// Atlas assumed: row 0 at top of image (v flipped in GL)
struct UV { float u, v; };

inline UV getBlockUV(BlockType t, Face f) {
    // Tile indices (col, row) in a 16x16 atlas
    // Feel free to remap to match your own texture atlas
    int col = 0, row = 0;
    switch (t) {
        case BlockType::GRASS:
            if (f == Face::TOP)    { col=0; row=0; }  // grass top
            else if(f==Face::BOTTOM){ col=2; row=0; }  // dirt
            else                   { col=3; row=0; }   // grass side
            break;
        case BlockType::DIRT:   col=2; row=0; break;
        case BlockType::STONE:  col=1; row=0; break;
        case BlockType::WOOD:
            if(f==Face::TOP||f==Face::BOTTOM){ col=5; row=1; }
            else { col=4; row=1; }
            break;
        case BlockType::LEAVES: col=4; row=3; break;
        case BlockType::SAND:   col=2; row=1; break;
        case BlockType::WATER:  col=13;row=12;break;
        default:                col=1; row=0; break; // fallback: stone
    }
    return { col * ATLAS_INV, row * ATLAS_INV };
}

// Per-face brightness (simple directional lighting)
inline float getFaceBrightness(Face f) {
    switch (f) {
        case Face::TOP:    return 1.00f;
        case Face::BOTTOM: return 0.50f;
        case Face::FRONT:
        case Face::BACK:   return 0.80f;
        case Face::LEFT:
        case Face::RIGHT:  return 0.65f;
    }
    return 1.0f;
}
