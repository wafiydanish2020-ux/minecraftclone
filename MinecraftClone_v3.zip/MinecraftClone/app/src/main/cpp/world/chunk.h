#pragma once
#include <GLES3/gl3.h>
#include <vector>
#include <cstdint>
#include "block.h"
#include "../utils/glm.h"

static constexpr int CHUNK_SIZE = 16;

// Vertex layout: x,y,z | u,v | light
struct Vertex {
    float x, y, z;
    float u, v;
    float light;
};

class Chunk {
public:
    int cx, cz;            // chunk coords (world = cx*16, cz*16)
    BlockType blocks[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE];

    GLuint vao = 0, vbo = 0;
    int vertexCount = 0;
    bool dirty = true;     // needs mesh rebuild

    Chunk(int cx, int cz) : cx(cx), cz(cz) {
        memset(blocks, 0, sizeof(blocks));
    }
    ~Chunk() { freeGPU(); }

    BlockType get(int x, int y, int z) const {
        if (x<0||x>=CHUNK_SIZE||y<0||y>=CHUNK_SIZE||z<0||z>=CHUNK_SIZE)
            return BlockType::AIR;
        return blocks[x][y][z];
    }
    void set(int x, int y, int z, BlockType t) {
        if (x<0||x>=CHUNK_SIZE||y<0||y>=CHUNK_SIZE||z<0||z>=CHUNK_SIZE) return;
        blocks[x][y][z] = t;
        dirty = true;
    }

    // Build greedy(ish) mesh — simple face culling
    void buildMesh() {
        std::vector<Vertex> verts;
        verts.reserve(4096);

        for (int x=0;x<CHUNK_SIZE;x++)
        for (int y=0;y<CHUNK_SIZE;y++)
        for (int z=0;z<CHUNK_SIZE;z++) {
            BlockType t = get(x,y,z);
            if (t == BlockType::AIR) continue;

            float wx = cx*CHUNK_SIZE + x;
            float wy =                 y;
            float wz = cz*CHUNK_SIZE + z;

            // Try each face
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::TOP,    0, 1, 0);
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::BOTTOM, 0,-1, 0);
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::FRONT,  0, 0, 1);
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::BACK,   0, 0,-1);
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::RIGHT,  1, 0, 0);
            tryFace(verts, t, wx,wy,wz, x,y,z, Face::LEFT,  -1, 0, 0);
        }

        uploadToGPU(verts);
        dirty = false;
    }

    void render() const {
        if (vao == 0 || vertexCount == 0) return;
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, vertexCount);
        glBindVertexArray(0);
    }

    void freeGPU() {
        if (vao) { glDeleteVertexArrays(1, &vao); vao = 0; }
        if (vbo) { glDeleteBuffers(1, &vbo);       vbo = 0; }
        vertexCount = 0;
    }

private:
    void tryFace(std::vector<Vertex>& verts,
                 BlockType t,
                 float wx, float wy, float wz,
                 int bx, int by, int bz,
                 Face face, int nx, int ny, int nz)
    {
        // Cull if neighbour is solid
        if (get(bx+nx, by+ny, bz+nz) != BlockType::AIR) return;
        if (t == BlockType::WATER &&
            face != Face::TOP &&
            get(bx+nx,by+ny,bz+nz) == BlockType::WATER) return;

        UV uv  = getBlockUV(t, face);
        float u0=uv.u, v0=uv.v;
        float u1=u0+ATLAS_INV, v1=v0+ATLAS_INV;
        float li = getFaceBrightness(face);

        // 4 corners for this face
        float p[4][3];
        switch (face) {
            case Face::TOP:
                p[0]={wx,   wy+1,wz  }; p[1]={wx+1,wy+1,wz  };
                p[2]={wx+1,wy+1,wz+1}; p[3]={wx,  wy+1,wz+1};
                break;
            case Face::BOTTOM:
                p[0]={wx,  wy,  wz+1}; p[1]={wx+1,wy,  wz+1};
                p[2]={wx+1,wy,  wz  }; p[3]={wx,  wy,  wz  };
                break;
            case Face::FRONT:
                p[0]={wx,  wy,  wz+1}; p[1]={wx+1,wy,  wz+1};
                p[2]={wx+1,wy+1,wz+1}; p[3]={wx,  wy+1,wz+1};
                break;
            case Face::BACK:
                p[0]={wx+1,wy,  wz  }; p[1]={wx,  wy,  wz  };
                p[2]={wx,  wy+1,wz  }; p[3]={wx+1,wy+1,wz  };
                break;
            case Face::RIGHT:
                p[0]={wx+1,wy,  wz+1}; p[1]={wx+1,wy,  wz  };
                p[2]={wx+1,wy+1,wz  }; p[3]={wx+1,wy+1,wz+1};
                break;
            case Face::LEFT:
                p[0]={wx,  wy,  wz  }; p[1]={wx,  wy,  wz+1};
                p[2]={wx,  wy+1,wz+1}; p[3]={wx,  wy+1,wz  };
                break;
        }
        // Quad = 2 triangles (indices 0,1,2 and 0,2,3)
        float uvs[4][2] = {{u0,v1},{u1,v1},{u1,v0},{u0,v0}};
        int tri[6] = {0,1,2, 0,2,3};
        for (int i : tri) {
            verts.push_back({p[i][0],p[i][1],p[i][2],
                             uvs[i][0],uvs[i][1], li});
        }
    }

    void uploadToGPU(const std::vector<Vertex>& verts) {
        freeGPU();
        if (verts.empty()) return;

        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER,
                     verts.size() * sizeof(Vertex),
                     verts.data(), GL_STATIC_DRAW);

        // aPos
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE,
                              sizeof(Vertex), (void*)offsetof(Vertex,x));
        glEnableVertexAttribArray(0);
        // aTexCoord
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE,
                              sizeof(Vertex), (void*)offsetof(Vertex,u));
        glEnableVertexAttribArray(1);
        // aLight
        glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE,
                              sizeof(Vertex), (void*)offsetof(Vertex,light));
        glEnableVertexAttribArray(2);

        glBindVertexArray(0);
        vertexCount = (int)verts.size();
    }
};
