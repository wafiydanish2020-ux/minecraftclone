#pragma once
#include "chunk.h"
#include <unordered_map>
#include <memory>
#include <cmath>

// Simple hash for chunk key
struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int>()(k.x) ^ (std::hash<int>()(k.z) << 16);
    }
};

// ── Minimal noise (integer hash-based) ──────────────────────────────────────
static inline float hashNoise(int x, int z) {
    int n = x + z * 57;
    n = (n << 13) ^ n;
    return 1.f - ((n*(n*n*15731+789221)+1376312589) & 0x7fffffff) / 1073741824.f;
}
static inline float smoothNoise(float x, float z) {
    int xi=(int)floorf(x), zi=(int)floorf(z);
    float fx=x-xi, fz=z-zi;
    // Hermite blend
    float ux=fx*fx*(3-2*fx), uz=fz*fz*(3-2*fz);
    float v00=hashNoise(xi,  zi  ), v10=hashNoise(xi+1,zi  );
    float v01=hashNoise(xi,  zi+1), v11=hashNoise(xi+1,zi+1);
    return v00*(1-ux)*(1-uz) + v10*ux*(1-uz)
          +v01*(1-ux)*uz     + v11*ux*uz;
}
static inline float fractalNoise(float x, float z, int oct=4) {
    float val=0, amp=1, freq=1, max=0;
    for(int i=0;i<oct;i++){
        val += smoothNoise(x*freq, z*freq)*amp;
        max += amp; amp*=0.5f; freq*=2.f;
    }
    return val/max;
}

class World {
public:
    static constexpr int RENDER_DIST = 4; // chunks

    World() {}

    void update(float camX, float camZ) {
        int ccx = (int)floorf(camX / CHUNK_SIZE);
        int ccz = (int)floorf(camZ / CHUNK_SIZE);

        // Load chunks in range
        for(int dx=-RENDER_DIST;dx<=RENDER_DIST;dx++)
        for(int dz=-RENDER_DIST;dz<=RENDER_DIST;dz++) {
            ChunkKey k{ccx+dx, ccz+dz};
            if(chunks.find(k)==chunks.end()) {
                auto c = std::make_unique<Chunk>(k.x, k.z);
                generateChunk(*c);
                chunks[k] = std::move(c);
            }
        }

        // Build dirty meshes
        for(auto& [k, c] : chunks)
            if(c->dirty) c->buildMesh();
    }

    void render() const {
        for(auto& [k, c] : chunks)
            c->render();
    }

    BlockType getBlock(int wx, int wy, int wz) const {
        int cx = (int)floorf((float)wx / CHUNK_SIZE);
        int cz = (int)floorf((float)wz / CHUNK_SIZE);
        auto it = chunks.find({cx, cz});
        if(it==chunks.end()) return BlockType::AIR;
        int lx = wx - cx*CHUNK_SIZE;
        int lz = wz - cz*CHUNK_SIZE;
        return it->second->get(lx, wy, lz);
    }

private:
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkKeyHash> chunks;

    void generateChunk(Chunk& c) {
        float baseX = c.cx * CHUNK_SIZE;
        float baseZ = c.cz * CHUNK_SIZE;

        for(int x=0;x<CHUNK_SIZE;x++)
        for(int z=0;z<CHUNK_SIZE;z++) {
            float nx = (baseX+x) * 0.05f;
            float nz = (baseZ+z) * 0.05f;
            float h  = fractalNoise(nx, nz);
            int height = (int)(h * 8 + 5); // 5..13
            height = std::min(height, CHUNK_SIZE-2);

            for(int y=0;y<CHUNK_SIZE;y++) {
                BlockType t;
                if      (y > height)   t = BlockType::AIR;
                else if (y == height)  t = BlockType::GRASS;
                else if (y >= height-3)t = BlockType::DIRT;
                else                   t = BlockType::STONE;
                c.set(x,y,z,t);
            }
            // Simple tree
            if(height > 4 && height < CHUNK_SIZE-5) {
                float tr = fractalNoise((baseX+x)*0.3f,(baseZ+z)*0.3f,1);
                if(tr > 0.6f) {
                    int trunk = height+1;
                    for(int ty=trunk;ty<=trunk+3;ty++)
                        c.set(x,ty,z,BlockType::WOOD);
                    for(int lx=-2;lx<=2;lx++)
                    for(int lz=-2;lz<=2;lz++)
                    for(int ly=trunk+2;ly<=trunk+5;ly++) {
                        if(abs(lx)+abs(lz)+abs(ly-trunk-3)<=3)
                            if(c.get(x+lx,ly,z+lz)==BlockType::AIR)
                                c.set(x+lx,ly,z+lz,BlockType::LEAVES);
                    }
                }
            }
        }
    }
};
