#pragma once
// stb_image.h diimplementasikan di texture_loader.h
// File ini hanya placeholder agar include path tetap bersih
#include "stb_image.h"
