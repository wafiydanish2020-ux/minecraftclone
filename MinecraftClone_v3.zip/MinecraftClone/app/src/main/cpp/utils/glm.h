#pragma once
#include <cmath>
#include <cstring>

// ─── vec2 ───────────────────────────────────────────────────────────────────
struct vec2 {
    float x, y;
    vec2(float x=0,float y=0): x(x),y(y){}
    vec2 operator+(const vec2& o) const { return {x+o.x, y+o.y}; }
    vec2 operator-(const vec2& o) const { return {x-o.x, y-o.y}; }
    vec2 operator*(float s)       const { return {x*s, y*s}; }
};

// ─── vec3 ───────────────────────────────────────────────────────────────────
struct vec3 {
    float x, y, z;
    vec3(float x=0,float y=0,float z=0): x(x),y(y),z(z){}

    vec3 operator+(const vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    vec3 operator-(const vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    vec3 operator*(float s)       const { return {x*s, y*s, z*s}; }
    vec3& operator+=(const vec3& o){ x+=o.x; y+=o.y; z+=o.z; return *this; }
    vec3& operator-=(const vec3& o){ x-=o.x; y-=o.y; z-=o.z; return *this; }

    float dot(const vec3& o)  const { return x*o.x + y*o.y + z*o.z; }
    float length()            const { return sqrtf(dot(*this)); }
    vec3  normalize()         const { float l=length(); return l>0?(*this)*(1/l):vec3{}; }
    vec3  cross(const vec3& o)const {
        return { y*o.z - z*o.y,
                 z*o.x - x*o.z,
                 x*o.y - y*o.x };
    }
};

// ─── mat4 (column-major) ────────────────────────────────────────────────────
struct mat4 {
    float m[16];

    mat4() { memset(m, 0, sizeof(m)); }

    static mat4 identity() {
        mat4 r;
        r.m[0]=r.m[5]=r.m[10]=r.m[15]=1.f;
        return r;
    }

    mat4 operator*(const mat4& o) const {
        mat4 r;
        for(int col=0;col<4;col++)
            for(int row=0;row<4;row++)
                for(int k=0;k<4;k++)
                    r.m[col*4+row] += m[k*4+row] * o.m[col*4+k];
        return r;
    }

    static mat4 perspective(float fovY, float aspect, float near, float far) {
        float f = 1.f / tanf(fovY * 0.5f);
        mat4 r;
        r.m[0]  =  f / aspect;
        r.m[5]  =  f;
        r.m[10] = (far + near) / (near - far);
        r.m[11] = -1.f;
        r.m[14] = (2.f * far * near) / (near - far);
        return r;
    }

    static mat4 lookAt(vec3 eye, vec3 center, vec3 up) {
        vec3 f = (center - eye).normalize();
        vec3 s = f.cross(up).normalize();
        vec3 u = s.cross(f);
        mat4 r = identity();
        r.m[0]=s.x;  r.m[4]=s.y;  r.m[8] =s.z;
        r.m[1]=u.x;  r.m[5]=u.y;  r.m[9] =u.z;
        r.m[2]=-f.x; r.m[6]=-f.y; r.m[10]=-f.z;
        r.m[12]=-s.dot(eye);
        r.m[13]=-u.dot(eye);
        r.m[14]= f.dot(eye);
        return r;
    }

    static mat4 translate(vec3 t) {
        mat4 r = identity();
        r.m[12]=t.x; r.m[13]=t.y; r.m[14]=t.z;
        return r;
    }

    static mat4 rotateY(float angle) {
        mat4 r = identity();
        r.m[0] =  cosf(angle);
        r.m[2] =  sinf(angle);
        r.m[8] = -sinf(angle);
        r.m[10]=  cosf(angle);
        return r;
    }
};
