#pragma once
#include "../utils/glm.h"
#include "../world/world.h"
#include <cmath>

static constexpr float PI = 3.14159265f;
static constexpr float DEG2RAD = PI / 180.f;

class Player {
public:
    vec3  pos    {8.f, 20.f, 8.f};  // spawn above terrain
    float yaw    = 0.f;              // degrees, horizontal
    float pitch  = 0.f;             // degrees, vertical clamp ±89

    vec3  velocity{0,0,0};
    bool  onGround = false;

    // Input state (set by touch handler)
    float moveForward = 0.f;  // -1..1
    float moveRight   = 0.f;
    bool  jumpPressed = false;

    static constexpr float GRAVITY      = -28.f;
    static constexpr float JUMP_SPEED   =  10.f;
    static constexpr float WALK_SPEED   =   5.f;
    static constexpr float PLAYER_H     =   1.8f;
    static constexpr float PLAYER_W     =   0.6f;

    void update(float dt, const World& world) {
        // ── Horizontal movement ─────────────────────────────────────────────
        float rad  = yaw * DEG2RAD;
        vec3 fwd   = { -sinf(rad), 0, -cosf(rad) };
        vec3 right = {  cosf(rad), 0, -sinf(rad) };

        vec3 move = fwd * moveForward + right * moveRight;
        if (move.length() > 0) move = move.normalize() * WALK_SPEED;
        velocity.x = move.x;
        velocity.z = move.z;

        // ── Gravity & jump ──────────────────────────────────────────────────
        if (jumpPressed && onGround) velocity.y = JUMP_SPEED;
        velocity.y += GRAVITY * dt;
        if (velocity.y < -50.f) velocity.y = -50.f;

        // ── Collision + move ────────────────────────────────────────────────
        vec3 delta = velocity * dt;
        moveWithCollision(delta, world);

        jumpPressed = false;
    }

    // Returns the camera eye position (slightly above feet)
    vec3 eyePos() const {
        return { pos.x, pos.y + PLAYER_H * 0.85f, pos.z };
    }

    vec3 lookDir() const {
        float pr = pitch * DEG2RAD;
        float yr = yaw   * DEG2RAD;
        return {
            cosf(pr) * -sinf(yr),
            sinf(pr),
            cosf(pr) * -cosf(yr)
        };
    }

    mat4 viewMatrix() const {
        vec3 eye = eyePos();
        return mat4::lookAt(eye, eye + lookDir(), {0,1,0});
    }

private:
    void moveWithCollision(vec3 delta, const World& world) {
        float hw = PLAYER_W * 0.5f;

        // Sweep each axis separately
        // X
        pos.x += delta.x;
        if (collidesWorld(world)) { pos.x -= delta.x; velocity.x = 0; }

        // Y
        pos.y += delta.y;
        if (collidesWorld(world)) {
            if (delta.y < 0) onGround = true;
            pos.y -= delta.y;
            velocity.y = 0;
        } else { onGround = false; }

        // Z
        pos.z += delta.z;
        if (collidesWorld(world)) { pos.z -= delta.z; velocity.z = 0; }
    }

    // Returns true if player AABB overlaps any solid block
    bool collidesWorld(const World& world) const {
        float hw = PLAYER_W * 0.5f;
        int x0 = (int)floorf(pos.x - hw);
        int x1 = (int)floorf(pos.x + hw);
        int y0 = (int)floorf(pos.y);
        int y1 = (int)floorf(pos.y + PLAYER_H);
        int z0 = (int)floorf(pos.z - hw);
        int z1 = (int)floorf(pos.z + hw);

        for(int x=x0;x<=x1;x++)
        for(int y=y0;y<=y1;y++)
        for(int z=z0;z<=z1;z++) {
            BlockType b = world.getBlock(x,y,z);
            if (b != BlockType::AIR && b != BlockType::WATER)
                return true;
        }
        return false;
    }
};
