#pragma once
#include <android/input.h>
#include "../utils/glm.h"
#include <cmath>

// Two-zone touch:
//  Left half  → virtual joystick (move)
//  Right half → drag to look

struct TouchInput {
    // Virtual joystick
    int   joyId      = -1;
    float joyStartX  = 0, joyStartY  = 0;
    float joyCurrX   = 0, joyCurrY   = 0;

    // Look drag
    int   lookId     = -1;
    float lookLastX  = 0, lookLastY  = 0;

    // Jump button (top-right corner)
    bool  jumpTapped = false;

    float screenW = 1, screenH = 1;

    // Call from onInputEvent
    bool processEvent(AInputEvent* event, float w, float h) {
        screenW = w; screenH = h;
        if (AInputEvent_getType(event) != AINPUT_EVENT_TYPE_MOTION) return false;

        int32_t action    = AMotionEvent_getAction(event);
        int32_t actionMask= action & AMOTION_EVENT_ACTION_MASK;
        int32_t pointerIdx= (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK)
                            >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;

        auto handleDown = [&](int idx) {
            int id = AMotionEvent_getPointerId(event, idx);
            float x = AMotionEvent_getX(event, idx);
            float y = AMotionEvent_getY(event, idx);

            // Jump zone: top-right 15% x 15%
            if (x > screenW*0.85f && y < screenH*0.15f) {
                jumpTapped = true;
                return;
            }
            if (x < screenW * 0.5f) {
                // Left half → joystick
                joyId=id; joyStartX=x; joyStartY=y; joyCurrX=x; joyCurrY=y;
            } else {
                // Right half → look
                lookId=id; lookLastX=x; lookLastY=y;
            }
        };

        auto handleUp = [&](int idx) {
            int id = AMotionEvent_getPointerId(event, idx);
            if (id == joyId)  { joyId=-1; }
            if (id == lookId) { lookId=-1; }
        };

        switch(actionMask) {
            case AMOTION_EVENT_ACTION_DOWN:
            case AMOTION_EVENT_ACTION_POINTER_DOWN:
                handleDown(pointerIdx); break;
            case AMOTION_EVENT_ACTION_UP:
            case AMOTION_EVENT_ACTION_POINTER_UP:
            case AMOTION_EVENT_ACTION_CANCEL:
                handleUp(pointerIdx); break;
            case AMOTION_EVENT_ACTION_MOVE:
                for(int i=0;i<(int)AMotionEvent_getPointerCount(event);i++){
                    int id=AMotionEvent_getPointerId(event,i);
                    float x=AMotionEvent_getX(event,i);
                    float y=AMotionEvent_getY(event,i);
                    if(id==joyId){ joyCurrX=x; joyCurrY=y; }
                    if(id==lookId){ lookLastX=x; lookLastY=y; }
                }
                break;
        }
        return true;
    }

    // Returns normalized movement vector (-1..1)
    vec2 getJoystick() const {
        if (joyId < 0) return {0,0};
        float dx = joyCurrX - joyStartX;
        float dy = joyCurrY - joyStartY;
        float deadzone = 10.f;
        float maxR     = 80.f;
        float d = sqrtf(dx*dx+dy*dy);
        if (d < deadzone) return {0,0};
        float nx = dx/d * fminf((d-deadzone)/(maxR-deadzone), 1.f);
        float ny = dy/d * fminf((d-deadzone)/(maxR-deadzone), 1.f);
        return {nx, ny};  // x=strafe, y=forward (screen y-down = negative z)
    }

    // Returns delta look since last call
    vec2 getLookDelta(float& lastX, float& lastY) {
        if (lookId < 0) { lastX = lookLastX; lastY = lookLastY; return {0,0}; }
        float dx = lookLastX - lastX;
        float dy = lookLastY - lastY;
        lastX = lookLastX;
        lastY = lookLastY;
        return {dx, dy};
    }
};
