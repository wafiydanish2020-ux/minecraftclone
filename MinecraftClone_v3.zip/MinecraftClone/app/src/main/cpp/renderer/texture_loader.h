#pragma once
#include <GLES3/gl3.h>
#include <android/asset_manager.h>
#include <android/log.h>
#include <cstdlib>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define LOG_TAG "MC_TEX"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

inline GLuint loadTextureFromAssets(AAssetManager* am, const char* path) {
    AAsset* asset = AAssetManager_open(am, path, AASSET_MODE_BUFFER);
    if (!asset) { LOGE("Cannot open asset: %s", path); return 0; }

    size_t size = AAsset_getLength(asset);
    unsigned char* buf = (unsigned char*)malloc(size);
    AAsset_read(asset, buf, size);
    AAsset_close(asset);

    int w, h, channels;
    stbi_set_flip_vertically_on_load(1);
    unsigned char* img = stbi_load_from_memory(buf, (int)size, &w, &h, &channels, 4);
    free(buf);

    if (!img) { LOGE("stbi failed: %s", path); return 0; }

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0,
                 GL_RGBA, GL_UNSIGNED_BYTE, img);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    stbi_image_free(img);
    return tex;
}
