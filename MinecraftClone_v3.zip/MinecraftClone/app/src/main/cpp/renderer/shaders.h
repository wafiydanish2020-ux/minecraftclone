#pragma once

// ─── Block / Chunk shader ───────────────────────────────────────────────────
static const char* BLOCK_VERT_SRC = R"(#version 300 es
precision mediump float;

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aLight;   // face ambient occlusion / brightness

uniform mat4 uMVP;

out vec2 vTexCoord;
out float vLight;

void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
    vTexCoord   = aTexCoord;
    vLight      = aLight;
}
)";

static const char* BLOCK_FRAG_SRC = R"(#version 300 es
precision mediump float;

in vec2  vTexCoord;
in float vLight;

uniform sampler2D uTexture;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(uTexture, vTexCoord);
    if (texColor.a < 0.1) discard;
    fragColor = vec4(texColor.rgb * vLight, texColor.a);
}
)";

// ─── Sky / background ───────────────────────────────────────────────────────
static const char* SKY_VERT_SRC = R"(#version 300 es
precision mediump float;
layout(location=0) in vec2 aPos;
void main(){ gl_Position = vec4(aPos, 0.999, 1.0); }
)";

static const char* SKY_FRAG_SRC = R"(#version 300 es
precision mediump float;
uniform vec2 uResolution;
out vec4 fragColor;
void main(){
    float t = gl_FragCoord.y / uResolution.y;
    vec3 top    = vec3(0.40, 0.65, 1.0);
    vec3 horizon= vec3(0.75, 0.88, 1.0);
    fragColor = vec4(mix(horizon, top, t), 1.0);
}
)";
