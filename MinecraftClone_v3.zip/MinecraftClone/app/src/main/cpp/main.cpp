#include <android_native_app_glue.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <cmath>
#include <chrono>

#include "renderer/shaders.h"
#include "renderer/shader_utils.h"
#include "renderer/texture_loader.h"
#include "world/world.h"
#include "player/player.h"
#include "player/touch_input.h"
#include "utils/glm.h"

#define LOG_TAG "MC_MAIN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Global state ─────────────────────────────────────────────────────────────
struct Engine {
    android_app*  app     = nullptr;
    EGLDisplay    display = EGL_NO_DISPLAY;
    EGLSurface    surface = EGL_NO_SURFACE;
    EGLContext    context = EGL_NO_CONTEXT;
    int32_t       width=0, height=0;

    GLuint blockProgram = 0;
    GLuint skyProgram   = 0;
    GLuint blockTexture = 0;

    // Sky quad VAO
    GLuint skyVAO=0, skyVBO=0;

    World       world;
    Player      player;
    TouchInput  touch;

    float lookX=0, lookY=0; // accumulated look drag position

    bool running = false;
    std::chrono::steady_clock::time_point lastTime;
};

// ── EGL setup ─────────────────────────────────────────────────────────────────
static bool initDisplay(Engine* e) {
    e->display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(e->display, nullptr, nullptr);

    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
        EGL_BLUE_SIZE,  8, EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE,   8, EGL_DEPTH_SIZE, 24,
        EGL_NONE
    };
    EGLConfig config; EGLint numConfigs;
    eglChooseConfig(e->display, attribs, &config, 1, &numConfigs);

    EGLint format; eglGetConfigAttrib(e->display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(e->app->window, 0, 0, format);

    e->surface = eglCreateWindowSurface(e->display, config, e->app->window, nullptr);
    const EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    e->context = eglCreateContext(e->display, config, EGL_NO_CONTEXT, ctxAttribs);

    if (eglMakeCurrent(e->display, e->surface, e->surface, e->context) == EGL_FALSE) {
        LOGE("eglMakeCurrent failed");
        return false;
    }
    eglQuerySurface(e->display, e->surface, EGL_WIDTH,  &e->width);
    eglQuerySurface(e->display, e->surface, EGL_HEIGHT, &e->height);
    return true;
}

// ── GL resource init ──────────────────────────────────────────────────────────
static void initGL(Engine* e) {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glViewport(0, 0, e->width, e->height);

    e->blockProgram = createProgram(BLOCK_VERT_SRC, BLOCK_FRAG_SRC);
    e->skyProgram   = createProgram(SKY_VERT_SRC,   SKY_FRAG_SRC);

    e->blockTexture = loadTextureFromAssets(e->app->activity->assetManager,
                                            "textures/terrain.png");

    // Sky fullscreen quad
    float skyVerts[] = { -1,-1,  1,-1,  1,1,  -1,-1,  1,1,  -1,1 };
    glGenVertexArrays(1, &e->skyVAO);
    glGenBuffers(1, &e->skyVBO);
    glBindVertexArray(e->skyVAO);
    glBindBuffer(GL_ARRAY_BUFFER, e->skyVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(skyVerts), skyVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    e->lastTime = std::chrono::steady_clock::now();
    e->running  = true;
}

// ── Render one frame ──────────────────────────────────────────────────────────
static void render(Engine* e) {
    // Delta time
    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - e->lastTime).count();
    e->lastTime = now;
    if (dt > 0.1f) dt = 0.1f; // cap

    // ── Input ──────────────────────────────────────────────────────────────
    vec2 joy = e->touch.getJoystick();
    e->player.moveForward = -joy.y; // screen y-down → negative z
    e->player.moveRight   =  joy.x;
    if (e->touch.jumpTapped) { e->player.jumpPressed = true; e->touch.jumpTapped = false; }

    vec2 lookDelta = e->touch.getLookDelta(e->lookX, e->lookY);
    float sensitivity = 0.2f;
    e->player.yaw   += lookDelta.x * sensitivity;
    e->player.pitch -= lookDelta.y * sensitivity;
    if (e->player.pitch >  89.f) e->player.pitch =  89.f;
    if (e->player.pitch < -89.f) e->player.pitch = -89.f;

    // ── World update ────────────────────────────────────────────────────────
    e->world.update(e->player.pos.x, e->player.pos.z);
    e->player.update(dt, e->world);

    // ── Draw ───────────────────────────────────────────────────────────────
    glClear(GL_DEPTH_BUFFER_BIT);

    // Sky (depth writes off)
    glDepthMask(GL_FALSE);
    glUseProgram(e->skyProgram);
    glUniform2f(glGetUniformLocation(e->skyProgram,"uResolution"),
                (float)e->width, (float)e->height);
    glBindVertexArray(e->skyVAO);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);
    glDepthMask(GL_TRUE);

    // Blocks
    float aspect = (float)e->width / (float)e->height;
    mat4 proj = mat4::perspective(70.f * 3.14159f/180.f, aspect, 0.1f, 200.f);
    mat4 view = e->player.viewMatrix();
    mat4 mvp  = proj * view;

    glUseProgram(e->blockProgram);
    glUniformMatrix4fv(glGetUniformLocation(e->blockProgram,"uMVP"),
                       1, GL_FALSE, mvp.m);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, e->blockTexture);
    glUniform1i(glGetUniformLocation(e->blockProgram,"uTexture"), 0);

    e->world.render();

    eglSwapBuffers(e->display, e->surface);
}

// ── Cleanup ───────────────────────────────────────────────────────────────────
static void destroyDisplay(Engine* e) {
    if (e->display != EGL_NO_DISPLAY) {
        eglMakeCurrent(e->display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
        if (e->context != EGL_NO_CONTEXT) eglDestroyContext(e->display, e->context);
        if (e->surface != EGL_NO_SURFACE) eglDestroySurface(e->display, e->surface);
        eglTerminate(e->display);
    }
    e->display = EGL_NO_DISPLAY;
    e->context = EGL_NO_CONTEXT;
    e->surface = EGL_NO_SURFACE;
    e->running = false;
}

// ── Android event handler ─────────────────────────────────────────────────────
static void handleAppCmd(android_app* app, int32_t cmd) {
    Engine* e = (Engine*)app->userData;
    switch(cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) { initDisplay(e); initGL(e); }
            break;
        case APP_CMD_TERM_WINDOW:
            destroyDisplay(e); break;
        case APP_CMD_GAINED_FOCUS:
            break;
        case APP_CMD_LOST_FOCUS:
            break;
    }
}

static int32_t handleInput(android_app* app, AInputEvent* event) {
    Engine* e = (Engine*)app->userData;
    return e->touch.processEvent(event, (float)e->width, (float)e->height) ? 1 : 0;
}

// ── Entry point ───────────────────────────────────────────────────────────────
void android_main(android_app* app) {
    Engine engine;
    engine.app = app;
    app->userData    = &engine;
    app->onAppCmd    = handleAppCmd;
    app->onInputEvent= handleInput;

    while (true) {
        int events;
        android_poll_source* source;
        // Poll events; if running render, else wait
        while (ALooper_pollAll(engine.running ? 0 : -1,
                               nullptr, &events,
                               (void**)&source) >= 0) {
            if (source) source->process(app, source);
            if (app->destroyRequested) { destroyDisplay(&engine); return; }
        }
        if (engine.running) render(&engine);
    }
}
